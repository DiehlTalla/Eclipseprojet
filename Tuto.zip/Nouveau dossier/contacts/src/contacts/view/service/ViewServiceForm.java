package contacts.view.service;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ViewServiceForm {
	@FXML
    private Label labId;

    @FXML
    private TextField tfnom;

    @FXML
    private ComboBox<?> cmbCategorie;

    @FXML
    private TextField tfdate;

    @FXML
    private TextField tflieu;

    @FXML
    private Button btnValider;

    @FXML
    void doAnnuler(ActionEvent event) {

    }

    @FXML
    void doCategorieSupprimer(ActionEvent event) {

    }

    @FXML
    void doValider(ActionEvent event) {

    }

}
