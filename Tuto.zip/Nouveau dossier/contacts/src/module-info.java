open module contacts {
	
	exports contacts;

	requires transitive jfox;
	requires org.mapstruct;
	requires javafx.base;
	requires java.desktop;
	requires javafx.graphics;
	requires javafx.swing;
	requires javafx.controls;
	requires javafx.fxml;

}