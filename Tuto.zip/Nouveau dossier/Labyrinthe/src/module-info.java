open module Labyrinthe {
	exports Labyrinthe;

	requires javafx.controls;
	requires javafx.graphics;
	requires transitive jfox;
	requires jakarta.inject;
	requires javafx.base;
	requires javafx.fxml;
	requires jakarta.annotation;
}